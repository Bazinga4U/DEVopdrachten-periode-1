Fahrenheit = int(input("Enter a value in Fahrenheit: "))

x = ((Fahrenheit - 32)/ 1.8)
output = round(x,2)
print(("The given value is: "),output ,("Celcius"))
